<template>
  <div>
    <h2>Sponsors</h2>

    <p>
      Stimulus Component is an MIT licensed open source project and completely free to use. However, the amount of
      effort needed to maintain and develop new features for the project is not sustainable without proper financial
      backing. You can support Stimulus Components development on
      <a href="https://github.com/sponsors/stimulus-components" target="_blank">GitHub Sponsors</a>. 🙏
    </p>

    <h2>Contributing</h2>

    <p>
      Do not hesitate to contribute to the project by adapting or adding features ! Bug reports or pull requests are
      welcome.
    </p>

    <p>
      Don't forget to drop a 🌟 on
      <a href="https://github.com/stimulus-components/stimulus-components" target="_blank">GitHub</a>
      to support the project.
    </p>

    <h2>License</h2>

    <p>
      This project is released under the
      <a href="https://opensource.org/licenses/MIT" target="_blank">MIT</a>
      license.
    </p>
  </div>
</template>
