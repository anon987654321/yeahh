<template>
  <div class="relative overflow-x-auto">
    <table class="w-full">
      <slot />
    </table>
  </div>
</template>
