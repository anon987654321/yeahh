//= require spree/backend
// Shipments AJAX API

//= require spree/backend/solidus_marketplace_routes
//= require spree/backend/suppliers_autocomplete