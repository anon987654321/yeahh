require 'spec_helper'

describe "Admin - Return Authorizations" do

  skip 'TODO: need to write, but should likely wait until after https://github.com/spree/spree/issues/4026'

end
