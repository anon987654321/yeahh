require 'spec_helper'

describe Spree::SupplierVariant do
  skip "add some examples to (or delete) #{__FILE__}"
end
