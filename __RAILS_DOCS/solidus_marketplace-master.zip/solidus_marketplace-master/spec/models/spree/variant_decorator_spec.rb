require 'spec_helper'

describe Spree::Variant do
  it 'should populate stock item for each of the master variant suppliers' do
    skip 'todo'
  end
end
